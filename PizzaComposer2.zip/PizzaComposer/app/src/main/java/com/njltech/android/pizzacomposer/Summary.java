package com.njltech.android.pizzacomposer;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class Summary extends AppCompatActivity {

   double pizza_crust1 = 5.0;
   double pizza_crust2 = 6.0;
   double pizza_crust3 = 7.0;

   double radioNeo = 5.0;
   double radioNY = 5.0;
   double radioPan = 5.0;
   double radioDeep = 5.0;
    double sum;
/* I can't convert nor set the strings to an integers, thats the biggest problem when doing the summary*/
   pizza_crust1 = items;
   pizza_crust2 = items;
   pizza_crust3 = items;

    Integer[] items;
    ArrayAdapter<Integer> adapter;
    public Summary() {
        items = new Integer[]{4,5,6};
        adapter = new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_item, items);

}
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);
        final RadioButton radioNeo = (RadioButton) findViewById(R.id.radioNeo);
        final RadioButton radioNY = (RadioButton) findViewById(R.id.radioNY);
        final RadioButton radioPan = (RadioButton) findViewById(R.id.radioPan);
        final RadioButton radioDeep = (RadioButton) findViewById(R.id.radioDeep);
        final TextView result = (TextView) findViewById(R.id.txtsum);
        Button calculate  = (Button) findViewById(R.id.Summary);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /* the sum should ideally look this*/
                sum = ((RadioButton + items + p)*0.06);

            }
        });

                Button button = (Button) findViewById(R.id.Enter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Summary.this, Contacts.class));
            }
        });

    }
}
/*
public class top {

    public static void main (String[]args){
        String[] pizzaTop = new pizzaTop();

    }
    public static class pizzaTop(double p){
        pizzaTop = p;
        p = 2.00;
    }




